"""Module for monitoring.video_recorder."""
